from veda.core.llm import VedaLLM
from veda.core.voice import VedaVoice
from veda.core.planner import TacticalFastPath
from veda.core.memory import VedaMemory
from veda.core.plugin_manager import PluginManager
from veda.utils.sanitizer import VedaSanitizer

class VedaAssistant:
    def __init__(self, gui):
        self.gui = gui
        self.memory = VedaMemory()
        self.llm = VedaLLM()
        self.voice = VedaVoice()
        self.planner = TacticalFastPath()
        
        # Initialize Plugin System
        self.plugin_manager = PluginManager(self)
        self.plugin_manager.discover_and_load()

    def process_command(self, user_input):
        """Processes a user command via the tiered pipeline."""
        if user_input == "system_stats_internal":
            return self.plugin_manager.handle_intent("system_stats", {})

        self.memory.log_interaction("user", user_input)

        cleaned_input = VedaSanitizer.clean_input(user_input)
        if not cleaned_input:
            return

        # 1. Tactical Fast-Path (Survival Mode)
        intent_data = self.planner.extract(cleaned_input)
        
        # 2. Fallback to LLM
        if not intent_data:
             intent_data = self.llm.extract_intent(cleaned_input)
        
        intent = intent_data.get("intent", "none")
        params = intent_data.get("params", {})

        # 3. Handle via Plugins
        response = self.plugin_manager.handle_intent(intent, params)

        # 4. Final Fallback to Chat
        if response is None:
            response = self.llm.chat(cleaned_input)

        # Log, Update UI and Speak
        self.memory.log_interaction("assistant", response)
        self.gui.update_chat("Veda", response)
        self.voice.speak(response)

    def listen_and_process(self):
        query = self.voice.listen()
        if query != "None":
            self.gui.update_chat("You", query)
            self.process_command(query)
        self.gui.reset_voice_button()
